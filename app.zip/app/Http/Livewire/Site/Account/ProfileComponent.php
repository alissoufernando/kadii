<?php

namespace App\Http\Livewire\Site\Account;

use Livewire\Component;

class ProfileComponent extends Component
{
    public function render()
    {
        return view('livewire.site.account.profile-component');
    }
}
