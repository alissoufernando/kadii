<?php

namespace App\Http\Livewire\Dashboard\Category;

use Livewire\Component;

class CategoryEditComponent extends Component
{
    public function render()
    {
        return view('livewire.dashboard.category.category-edit-component');
    }
}
