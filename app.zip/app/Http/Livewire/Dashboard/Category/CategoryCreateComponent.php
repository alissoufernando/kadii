<?php

namespace App\Http\Livewire\Dashboard\Category;

use Livewire\Component;

class CategoryCreateComponent extends Component
{
    public function render()
    {
        return view('livewire.dashboard.category.category-create-component');
    }
}
