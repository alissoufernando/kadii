<?php

namespace App\Http\Livewire\Dashboard\Parametre;

use Livewire\Component;

class CreateCarametreComponent extends Component
{
    public function render()
    {
        return view('livewire.dashboard.parametre.create-carametre-component');
    }
}
