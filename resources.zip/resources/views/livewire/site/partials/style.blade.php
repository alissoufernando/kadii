
<!-- Animation CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/css/animate.css')}}">
<!-- Latest Bootstrap min CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/bootstrap/css/bootstrap.min.css')}}">
<!--- owl carousel CSS-->
<link rel="stylesheet" href="{{asset('assets/site/assets/owlcarousel/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/owlcarousel/css/owl.theme.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/owlcarousel/css/owl.theme.default.min.css')}}">
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
<!-- Icon Font CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/css/all.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/ionicons.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/themify-icons.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/linearicons.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/flaticon.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/simple-line-icons.css')}}">
<!-- Magnific Popup CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/css/magnific-popup.css')}}">
<!-- Slick CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/css/slick.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/slick-theme.css')}}">
<!-- Style CSS -->
<link rel="stylesheet" href="{{asset('assets/site/assets/css/style.css')}}">
<link rel="stylesheet" href="{{asset('assets/site/assets/css/responsive.css')}}">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

