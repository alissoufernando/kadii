<a class="navbar-brand" id="link_logo" href="{{route('welcome')}}">
    {{-- <img class="logo_light" id="logo" src="{{asset('assets/site/assets/images/logo_sb_1.png')}}" alt="logo" width="90" height="90" /> --}}
    <img class="logo_dark" id="logo" src="{{asset('assets/site/assets/images/logo_sb_1.png')}}" alt="logo" />
    {{-- <img class="logo_dark" src="{{asset('assets/site/images/logo_sb_1.png')}}" alt="logo" /> --}}
</a>
