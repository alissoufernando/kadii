
   <div>
    <div class="search_wrap">
        <span class="close-search"><i class="ion-ios-close-empty"></i></span>
        <form action="{{route('site.search')}}">
            <input type="text" placeholder="Search" value="" class="form-control" id="search_input">
            <button type="submit" class="search_icon"><i class="ion-ios-search-strong"></i></button>
        </form>
    </div><div class="search_overlay"></div>
   </div>

